#!/usr/bin/env bash
set -e
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle is not installed. Use Android Studio or GitHub Actions workflow .github/workflows/build-apk.yml"
  exit 1
fi
gradle --no-daemon assembleDebug
