#!/usr/bin/env bash
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
JAVA="$ROOT/app/src/main/java/com/example/jellymarket/MainActivity.java"
grep -q '3.0-complete' "$ROOT/app/build.gradle"
grep -q 'WS_BANK = "26009"' "$JAVA"
grep -q 'ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)' "$JAVA"
grep -q 'getInt(43)' "$JAVA"
grep -q 'getLong(115)' "$JAVA"
python3 - <<PY
from pathlib import Path
p=Path('$ROOT/app/src/main/java/com/example/jellymarket/MainActivity.java').read_text()
assert p.count('{') == p.count('}')
assert p.count('(') == p.count(')')
assert p.count('[') == p.count(']')
print('JellyMarket v2.5 source sanity checks: PASS')
PY

# Historical BANK token must remain distinct from the WebSocket token.
grep -q 'final String NIFTY = "99926000", BANK = "99926009"' "$JAVA"

grep -q "lastWsTickAt" "$JAVA"
grep -q "fetchInFlight" "$JAVA"

grep -q 'cancelReconnect' "$JAVA"
grep -q 'Jelly paused' "$JAVA"
