package com.example.jellymarket;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.speech.tts.TextToSpeech;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.text.*;
import java.util.*;
import java.nio.*;
import okhttp3.*;

public class MainActivity extends Activity {
    LinearLayout body;
    TextView nifty, bank, marketView, signal, status, levels, technicals;
    Timer timer;
    TextToSpeech tts;
    PriceChart chart;
    Button logoutBtn;
    final ArrayList<Double> niftyHistory = new ArrayList<>();
    final ArrayList<Double> bankHistory = new ArrayList<>();

    final int DARK = Color.rgb(11,18,32), CARD = Color.rgb(28,39,58),
            GREEN = Color.rgb(40,190,110), RED = Color.rgb(235,75,75),
            WHITE = Color.WHITE, YELLOW = Color.rgb(255,193,7);
    final String ROOT = "https://apiconnect.angelone.in";
    final String LOGIN = ROOT + "/rest/auth/angelbroking/user/v1/loginByPassword";
    final String QUOTE = ROOT + "/rest/secure/angelbroking/market/v1/quote/";
    final String NIFTY = "99926000", BANK = "99926009";
    SharedPreferences prefs;
    volatile String authToken = "";
    volatile String feedToken = "";
    OkHttpClient wsClient;
    WebSocket webSocket;
    Handler wsHandler;
    Runnable heartbeat;
    int reconnectAttempt = 0;
    volatile boolean reconnectScheduled = false;
    volatile boolean manualLogout = false;
    volatile boolean fetchInFlight = false;
    volatile long lastWsTickAt = 0L;
    Runnable wsWatchdog;
    Runnable reconnectRunnable;
    final String WS_URL = "wss://smartapisocket.angelone.in/smart-stream";
    final String WS_NIFTY = "26000";
    final String WS_BANK = "26009";

    TextView tv(String s, int sp) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(WHITE); t.setPadding(18,12,18,12);
        return t;
    }

    TextView card(String title, String value, String sub, int color) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL); c.setPadding(14,10,14,10); c.setBackgroundColor(CARD);
        TextView a = tv(title,13), b = tv(value,25), d = tv(sub,12);
        b.setTextColor(color); c.addView(a); c.addView(b); c.addView(d);
        body.addView(c,new LinearLayout.LayoutParams(-1,-2));
        Space sp = new Space(this); body.addView(sp,new LinearLayout.LayoutParams(1,8));
        return b;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("jelly",0);
        tts = new TextToSpeech(this,s->{ if(s==TextToSpeech.SUCCESS) tts.setLanguage(new Locale("hi","IN")); });
        wsHandler = new Handler(Looper.getMainLooper());
        wsClient = new OkHttpClient.Builder().pingInterval(0, java.util.concurrent.TimeUnit.SECONDS).build();
        build();
    }

    void build() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(DARK);
        TextView h = tv("JELLY MARKET\nANGEL ONE • NIFTY • BANK NIFTY",21);
        h.setTypeface(null,1); h.setPadding(18,22,18,14); root.addView(h);

        ScrollView sc = new ScrollView(this);
        body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(12,8,12,18);
        sc.addView(body); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));

        nifty = card("NIFTY 50","--","Angel One SmartAPI",YELLOW);
        bank = card("BANK NIFTY","--","Angel One SmartAPI",YELLOW);
        marketView = card("MARKET VIEW","--","Momentum + technical snapshot",YELLOW);
        signal = card("JELLY SIGNAL","WAIT","EMA20 + RSI14 + momentum • not financial advice",YELLOW);
        technicals = card("TECHNICALS","Waiting for history...","EMA20 / RSI14 / momentum",WHITE);
        levels = card("LEVELS","--","Day low / high estimate",WHITE);

        LinearLayout newsBox = new LinearLayout(this); newsBox.setOrientation(LinearLayout.VERTICAL);
        newsBox.setPadding(14,10,14,10); newsBox.setBackgroundColor(CARD);
        TextView newsTitle = tv("NEWS / SENTIMENT",16); newsTitle.setTypeface(null,1); newsBox.addView(newsTitle);
        TextView newsStatus = tv("Loading market news...",13); newsStatus.setTextColor(WHITE); newsBox.addView(newsStatus);
        Button newsRefresh = new Button(this); newsRefresh.setText("REFRESH NEWS"); newsBox.addView(newsRefresh);
        body.addView(newsBox); Space newsSp = new Space(this); body.addView(newsSp,new LinearLayout.LayoutParams(1,8));

        chart = new PriceChart(this); chart.setBackgroundColor(CARD); body.addView(chart,new LinearLayout.LayoutParams(-1,300));
        Space sp = new Space(this); body.addView(sp,new LinearLayout.LayoutParams(1,8));
        TextView note = tv("Jelly does not place trades. Signals are indicators, not guaranteed predictions. Market data may be unavailable outside exchange hours.",12);
        note.setTextColor(Color.LTGRAY); body.addView(note);

        Button settings = new Button(this); settings.setText("🔑 ANGEL ONE / SMARTAPI SETTINGS"); body.addView(settings);
        logoutBtn = new Button(this); logoutBtn.setText("LOGOUT / CLEAR SESSION"); body.addView(logoutBtn);
        LinearLayout actions = new LinearLayout(this);
        Button refresh = new Button(this); refresh.setText("REFRESH NOW");
        Button voice = new Button(this); voice.setText("🎙 HINDI VOICE");
        actions.addView(refresh,new LinearLayout.LayoutParams(0,-2,1)); actions.addView(voice,new LinearLayout.LayoutParams(0,-2,1));
        body.addView(actions);
        status = tv("Jelly v3.0 ready • Complete live market engine",12); status.setTextColor(Color.LTGRAY); body.addView(status);

        settings.setOnClickListener(v->showSettings()); refresh.setOnClickListener(v->fetch());
        voice.setOnClickListener(v->speakSummary()); logoutBtn.setOnClickListener(v->logout());
        newsRefresh.setOnClickListener(v->loadNews(newsStatus)); loadNews(newsStatus); setContentView(root);
        new Handler().postDelayed(()->{ if(prefs.getString("apiKey","").isEmpty()) showSettings(); },400);
    }

    void showSettings() {
        LinearLayout box = new LinearLayout(this); box.setPadding(24,4,24,4); box.setOrientation(LinearLayout.VERTICAL);
        EditText api = new EditText(this); api.setHint("Angel One API Key"); api.setSingleLine(true); api.setText(prefs.getString("apiKey",""));
        EditText client = new EditText(this); client.setHint("Client ID"); client.setSingleLine(true); client.setText(prefs.getString("client",""));
        EditText pin = new EditText(this); pin.setHint("Trading PIN / password (not saved)"); pin.setSingleLine(true); pin.setInputType(2|16);
        EditText totp = new EditText(this); totp.setHint("Current 6-digit TOTP (not saved)"); totp.setSingleLine(true); totp.setInputType(2);
        box.addView(api); box.addView(client); box.addView(pin); box.addView(totp);
        TextView info = tv("API key + Client ID can be saved locally. PIN and TOTP are used only for login and are not saved by Jelly. Never share these credentials.",12);
        info.setTextColor(Color.DKGRAY); box.addView(info);
        new AlertDialog.Builder(this).setTitle("Angel One SmartAPI") .setView(box)
            .setPositiveButton("LOGIN & START",(d,w)->{
                prefs.edit().putString("apiKey",api.getText().toString().trim()).putString("client",client.getText().toString().trim()).apply();
                login(client.getText().toString().trim(),pin.getText().toString().trim(),totp.getText().toString().trim());
            }).setNegativeButton("CANCEL",null).show();
    }

    void login(String client,String pin,String totp) {
        final String api = prefs.getString("apiKey","");
        if(api.isEmpty()||client.isEmpty()||pin.isEmpty()||totp.isEmpty()) { status.setText("API Key, Client ID, PIN and current TOTP are required"); return; }
        status.setText("Connecting to Angel One...");
        new Thread(()->{
            try {
                JSONObject body = new JSONObject(); body.put("clientcode",client); body.put("password",pin); body.put("totp",totp);
                HttpURLConnection c = (HttpURLConnection)new URL(LOGIN).openConnection(); c.setRequestMethod("POST");
                c.setConnectTimeout(15000); c.setReadTimeout(15000); setHeaders(c,api,""); c.setDoOutput(true); write(c,body.toString());
                int code=c.getResponseCode(); String json=read(code>=200&&code<300?c.getInputStream():c.getErrorStream());
                JSONObject r=new JSONObject(json);
                if(code==401||code==403) throw new Exception("Angel One rejected login request (HTTP "+code+")");
                if(code<200||code>=300||!r.optBoolean("status")) throw new Exception(r.optString("message","Login failed"));
                JSONObject data=r.getJSONObject("data");
                authToken=data.getString("jwtToken");
                feedToken=data.optString("feedToken","");
                if(feedToken.isEmpty()) throw new Exception("Feed token missing from Angel One login response");
                runOnUiThread(()->{status.setText("Angel One login successful • Live WebSocket starting..."); startLive();});
            } catch(Exception e) { runOnUiThread(()->status.setText("Angel One login error: "+e.getMessage())); }
        }).start();
    }

    void startLive() {
        manualLogout=false; reconnectAttempt=0; cancelReconnect();
        if(timer!=null) timer.cancel();
        niftyHistory.clear(); bankHistory.clear(); chart.clear();
        fetchHistoricalSeed();
        fetch();
        connectWebSocket();
        // REST remains as a safety fallback/periodic baseline while WebSocket supplies ticks.
        timer=new Timer(); timer.scheduleAtFixedRate(new TimerTask(){ public void run(){ fetch(); } },15000,15000);
    }

    void connectWebSocket() {
        if(manualLogout || authToken.isEmpty() || feedToken.isEmpty()) return;
        reconnectScheduled=false;
        try { if(webSocket!=null) webSocket.cancel(); } catch(Exception ignored) {}
        String api=prefs.getString("apiKey","");
        String client=prefs.getString("client","");
        Request req=new Request.Builder().url(WS_URL)
                .addHeader("Authorization","Bearer "+authToken)
                .addHeader("x-api-key",api)
                .addHeader("x-client-code",client)
                .addHeader("x-feed-token",feedToken).build();
        webSocket=wsClient.newWebSocket(req,new WebSocketListener(){
            @Override public void onOpen(WebSocket ws,Response response){
                reconnectAttempt=0; reconnectScheduled=false;
        lastWsTickAt=System.currentTimeMillis();
                JSONObject root=new JSONObject();
                try {
                    root.put("correlationID","jelly-live"); root.put("action",1);
                    JSONObject params=new JSONObject(); params.put("mode",2);
                    JSONArray list=new JSONArray();
                    JSONObject n=new JSONObject(); n.put("exchangeType",1); JSONArray nt=new JSONArray(); nt.put(WS_NIFTY); nt.put(WS_BANK); n.put("tokens",nt); list.put(n);
                    params.put("tokenList",list); root.put("params",params);
                    ws.send(root.toString());
                    runOnUiThread(()->status.setText("LIVE • WebSocket 2.0 connected"));
                    scheduleHeartbeat();
                    scheduleWatchdog();
                } catch(Exception e){ runOnUiThread(()->status.setText("WebSocket subscribe error: "+e.getMessage())); }
            }
            @Override public void onMessage(WebSocket ws,String text){ if("pong".equalsIgnoreCase(text)) return; }
            @Override public void onMessage(WebSocket ws,ByteString bytes){ parseWsPacket(bytes.toByteArray()); }
            @Override public void onFailure(WebSocket ws,Throwable t,Response r){ cancelWatchdog(); scheduleReconnect("WebSocket error: "+(t.getMessage()==null?"connection failed":t.getMessage())); }
            @Override public void onClosing(WebSocket ws,int code,String reason){ ws.close(1000,reason); }
            @Override public void onClosed(WebSocket ws,int code,String reason){ cancelWatchdog(); if(!manualLogout) scheduleReconnect("WebSocket disconnected"); }
        });
    }

    void scheduleWatchdog(){
        if(wsHandler==null) return;
        cancelWatchdog();
        wsWatchdog=()->{
            if(manualLogout) return;
            long age=System.currentTimeMillis()-lastWsTickAt;
            if(age>45000L){
                try{ if(webSocket!=null) webSocket.cancel(); }catch(Exception ignored){}
                scheduleReconnect("Live feed stale");
            } else {
                wsHandler.postDelayed(wsWatchdog,15000);
            }
        };
        wsHandler.postDelayed(wsWatchdog,15000);
    }

    void cancelWatchdog(){
        if(wsHandler!=null && wsWatchdog!=null) wsHandler.removeCallbacks(wsWatchdog);
        wsWatchdog=null;
    }

    void scheduleHeartbeat(){
        if(wsHandler==null) return;
        if(heartbeat!=null) wsHandler.removeCallbacks(heartbeat);
        heartbeat=()->{
            try { if(webSocket!=null) webSocket.send("ping"); } catch(Exception ignored) {}
            if(!manualLogout) wsHandler.postDelayed(heartbeat,30000);
        };
        wsHandler.postDelayed(heartbeat,30000);
    }

    void scheduleReconnect(String msg){
        if(manualLogout || wsHandler==null || reconnectScheduled) return;
        reconnectScheduled=true;
        int delay=(int)Math.min(30000,3000L*Math.pow(2,Math.min(reconnectAttempt,3))); reconnectAttempt++;
        runOnUiThread(()->status.setText(msg+" • reconnecting in "+(delay/1000)+"s"));
        reconnectRunnable=()->{ reconnectScheduled=false; connectWebSocket(); };
        wsHandler.postDelayed(reconnectRunnable,delay);
    }

    void cancelReconnect(){
        if(wsHandler!=null && reconnectRunnable!=null) wsHandler.removeCallbacks(reconnectRunnable);
        reconnectRunnable=null; reconnectScheduled=false;
    }

    void parseWsPacket(byte[] data){
        try {
            lastWsTickAt=System.currentTimeMillis();
            if(data==null || data.length<51) return;
            if(data.length==4 && data[0]=='p'&&data[1]=='o'&&data[2]=='n'&&data[3]=='g') return;
            int mode=data[0]&0xff; if(mode<1 || mode>3) return;
            String token=new String(data,2,25,"UTF-8").replace("\u0000","").trim();
            ByteBuffer bb=ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
            long ltpRaw=bb.getInt(43)&0xffffffffL; double ltp=ltpRaw/100.0;
            if(mode==1){ processWsPrice(token,ltp,ltp,ltp,ltp); return; }
            if(data.length<123) return;
            double close=bb.getLong(115)/100.0;
            double high=bb.getLong(99)/100.0, low=bb.getLong(107)/100.0;
            processWsPrice(token,ltp,close,high,low);
        } catch(Exception e){ runOnUiThread(()->status.setText("WebSocket packet skipped • "+e.getMessage())); }
    }

    void processWsPrice(String token,double ltp,double close,double high,double low){
        if(!(WS_NIFTY.equals(token)||WS_BANK.equals(token))) return;
        synchronized(niftyHistory){
            if(WS_NIFTY.equals(token)) addHistory(niftyHistory,ltp); else addHistory(bankHistory,ltp);
        }
        updateTechnicalDashboard(ltp,close,high,low,WS_NIFTY.equals(token));
    }

    void updateTechnicalDashboard(double ltp,double close,double high,double low,boolean isNifty){
        runOnUiThread(()->{
            TextView out=isNifty?nifty:bank; update(ltp,close,out);
            ArrayList<Double> hN=new ArrayList<>(niftyHistory), hB=new ArrayList<>(bankHistory);
            double nl=hN.isEmpty()?ltp:hN.get(hN.size()-1), bl=hB.isEmpty()?ltp:hB.get(hB.size()-1);
            double ne=ema(hN,20),be=ema(hB,20),nr=rsi(hN,14),br=rsi(hB,14),nm=momentum(hN),bm=momentum(hB);
            double score=technicalScore(nl,ne,nr,nm,bl,be,br,bm);
            String view=score>0.25?"BULLISH":score<-0.25?"BEARISH":"SIDEWAYS";
            String sig=score>0.55?"BUY BIAS":score<-0.55?"SELL BIAS":"WAIT / HOLD";
            int confidence=(int)Math.round(Math.min(99,Math.abs(score)*100));
            marketView.setText(view); marketView.setTextColor(view.equals("BULLISH")?GREEN:view.equals("BEARISH")?RED:YELLOW);
            signal.setText(sig+"  •  "+confidence+"%"); signal.setTextColor(sig.startsWith("BUY")?GREEN:sig.startsWith("SELL")?RED:YELLOW);
            technicals.setText(String.format(Locale.US,"NIFTY EMA20 %.2f • RSI14 %.1f • Mom %+.2f%%\nBANK EMA20 %.2f • RSI14 %.1f • Mom %+.2f%%\nConfidence %d%%",ne,nr,nm*100,be,br,bm*100,confidence));
            if(isNifty) levels.setText(String.format(Locale.US,"NIFTY Support %.2f • Resistance %.2f",low,high));
            chart.add(score);
            status.setText("LIVE • WebSocket 2.0 • "+new SimpleDateFormat("HH:mm:ss",Locale.US).format(new Date()));
        });
    }

    void logout() {
        manualLogout=true; reconnectScheduled=false;
        if(timer!=null){timer.cancel();timer=null;}
        if(wsHandler!=null && heartbeat!=null) wsHandler.removeCallbacks(heartbeat);
        cancelWatchdog();
        try { if(webSocket!=null) webSocket.close(1000,"logout"); } catch(Exception ignored) {}
        webSocket=null; authToken=""; feedToken=""; niftyHistory.clear(); bankHistory.clear(); chart.clear();
        prefs.edit().remove("apiKey").remove("client").apply();
        nifty.setText("--"); bank.setText("--"); marketView.setText("--"); signal.setText("WAIT");
        technicals.setText("Waiting for history..."); levels.setText("--"); status.setText("Logged out. Add Angel One SmartAPI details to reconnect.");
    }

    boolean marketHours(){
        Calendar c=Calendar.getInstance(); int d=c.get(Calendar.DAY_OF_WEEK), h=c.get(Calendar.HOUR_OF_DAY), m=c.get(Calendar.MINUTE);
        if(d==Calendar.SATURDAY || d==Calendar.SUNDAY) return false;
        int mins=h*60+m; return mins>=555 && mins<=930;
    }

    void fetchHistoricalSeed() {
        if (authToken.isEmpty() || !marketHours()) return;
        final String api = prefs.getString("apiKey", "");
        new Thread(() -> {
            try {
                Calendar end = Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata"));
                Calendar start = (Calendar) end.clone();
                start.add(Calendar.MINUTE, -30);
                SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
                fmt.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
                ArrayList<Double> n = loadCandles(api, NIFTY, fmt.format(start.getTime()), fmt.format(end.getTime()));
                ArrayList<Double> b = loadCandles(api, BANK, fmt.format(start.getTime()), fmt.format(end.getTime()));
                synchronized (niftyHistory) {
                    if (niftyHistory.size() < 3 && !n.isEmpty()) { niftyHistory.clear(); niftyHistory.addAll(n); }
                    if (bankHistory.size() < 3 && !b.isEmpty()) { bankHistory.clear(); bankHistory.addAll(b); }
                }
                runOnUiThread(() -> status.setText("Historical seed loaded • live feed starting"));
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("Historical seed unavailable • live feed continuing"));
            }
        }).start();
    }

    ArrayList<Double> loadCandles(String api, String token, String from, String to) throws Exception {
        ArrayList<Double> out = new ArrayList<>();
        JSONObject payload = new JSONObject();
        payload.put("exchange", "NSE");
        payload.put("symboltoken", token);
        payload.put("interval", "ONE_MINUTE");
        payload.put("fromdate", from);
        payload.put("todate", to);
        HttpURLConnection c = (HttpURLConnection) new URL(ROOT + "/rest/secure/angelbroking/historical/v1/getCandleData").openConnection();
        c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(15000);
        setHeaders(c, api, authToken); c.setDoOutput(true); write(c, payload.toString());
        int code = c.getResponseCode();
        String json = read(code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream());
        if (code < 200 || code >= 300) throw new Exception("Historical API " + code);
        JSONObject r = new JSONObject(json);
        if (!r.optBoolean("status", false)) throw new Exception(r.optString("message", "Historical data failed"));
        JSONArray rows = r.optJSONArray("data");
        if (rows == null) return out;
        for (int i = 0; i < rows.length(); i++) {
            JSONArray row = rows.optJSONArray(i);
            if (row != null && row.length() >= 5) out.add(row.optDouble(4, 0));
        }
        return out;
    }

    void fetch() {
        if(fetchInFlight) return;
        final String api=prefs.getString("apiKey","");
        if(authToken.isEmpty()){runOnUiThread(()->status.setText("Login first: Angel One / SmartAPI Settings"));return;}
        if(!marketHours()){ runOnUiThread(()->status.setText("Market closed • Live feed will resume during NSE hours")); return; }
        fetchInFlight=true;
        new Thread(()->{
            try {
                JSONObject payload=new JSONObject(); payload.put("mode","FULL");
                JSONObject ex=new JSONObject(); JSONArray arr=new JSONArray(); arr.put(NIFTY); arr.put(BANK); ex.put("NSE",arr); payload.put("exchangeTokens",ex);
                HttpURLConnection c=(HttpURLConnection)new URL(QUOTE).openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(15000);
                setHeaders(c,api,authToken); c.setDoOutput(true); write(c,payload.toString());
                int code=c.getResponseCode(); String json=read(code>=200&&code<300?c.getInputStream():c.getErrorStream());
                if(code<200||code>=300) throw new Exception("API "+code+": "+json);
                JSONObject r=new JSONObject(json); if(!r.optBoolean("status")) throw new Exception(r.optString("message","Quote failed"));
                JSONArray fetched=r.getJSONObject("data").optJSONArray("fetched"); if(fetched==null) throw new Exception("No market data");
                JSONObject n=null,b=null; for(int i=0;i<fetched.length();i++){JSONObject x=fetched.getJSONObject(i); if(NIFTY.equals(x.optString("symbolToken")))n=x; if(BANK.equals(x.optString("symbolToken")))b=x;}
                if(n==null||b==null) throw new Exception("Nifty/Bank Nifty data missing");
                double nl=n.getDouble("ltp"), bl=b.getDouble("ltp");
                double nc=n.optDouble("close",nl), bc=b.optDouble("close",bl);
                double nh=n.optDouble("high",nl), nn=n.optDouble("low",nl), bh=b.optDouble("high",bl), bn=b.optDouble("low",bl);
                synchronized(niftyHistory){addHistory(niftyHistory,nl);addHistory(bankHistory,bl);}
                double nEma=ema(niftyHistory,20), bEma=ema(bankHistory,20), nRsi=rsi(niftyHistory,14), bRsi=rsi(bankHistory,14);
                double nMom=momentum(niftyHistory), bMom=momentum(bankHistory);
                double score=technicalScore(nl,nEma,nRsi,nMom,bl,bEma,bRsi,bMom);
                String view=score>0.25?"BULLISH":score<-0.25?"BEARISH":"SIDEWAYS";
                String sig=score>0.55?"BUY BIAS":score<-0.55?"SELL BIAS":"WAIT / HOLD";
                int confidence=(int)Math.round(Math.min(99,Math.abs(score)*100));
                String lev=String.format(Locale.US,"Support %.2f / %.2f  •  Resistance %.2f / %.2f",nn,bn,nh,bh);
                String tech=String.format(Locale.US,"NIFTY EMA20 %.2f • RSI14 %.1f • Mom %+.2f%%\nBANK EMA20 %.2f • RSI14 %.1f • Mom %+.2f%%\nConfidence %d%%",nEma,nRsi,nMom*100,bEma,bRsi,bMom*100,confidence);
                runOnUiThread(()->{
                    update(nl,nc,nifty); update(bl,bc,bank);
                    marketView.setText(view); marketView.setTextColor(view.equals("BULLISH")?GREEN:view.equals("BEARISH")?RED:YELLOW);
                    signal.setText(sig+"  •  "+confidence+"%"); signal.setTextColor(sig.startsWith("BUY")?GREEN:sig.startsWith("SELL")?RED:YELLOW);
                    technicals.setText(tech); levels.setText(lev); chart.add(score);
                    status.setText("LIVE • Angel One SmartAPI • "+new SimpleDateFormat("HH:mm:ss",Locale.US).format(new Date()));
                });
            } catch(Exception e) {
                String msg=e.getMessage()==null?"Unknown error":e.getMessage();
                runOnUiThread(()->{
                    if(msg.contains("API 401") || msg.contains("API 403")){
                        status.setText("Angel One session expired • Login again");
                    } else {
                        status.setText("Live API error: "+msg);
                    }
                });
            } finally { fetchInFlight=false; }
        }).start();
    }

    void addHistory(ArrayList<Double> h,double value){h.add(value);if(h.size()>120)h.remove(0);}

    double ema(ArrayList<Double> h,int period){
        if(h.isEmpty())return 0; int start=Math.max(0,h.size()-period); double e=h.get(start);
        double k=2.0/(period+1); for(int i=start+1;i<h.size();i++)e=h.get(i)*k+e*(1-k); return e;
    }

    double rsi(ArrayList<Double> h,int period){
        if(h.size()<2)return 50; int start=Math.max(1,h.size()-period); double gain=0,loss=0;
        for(int i=start;i<h.size();i++){double d=h.get(i)-h.get(i-1);if(d>0)gain+=d;else loss-=d;}
        int n=Math.max(1,h.size()-start); gain/=n; loss/=n; if(loss==0)return gain>0?100:50; return 100-(100/(1+(gain/loss)));
    }

    double momentum(ArrayList<Double> h){if(h.size()<2)return 0;double old=h.get(Math.max(0,h.size()-6)),now=h.get(h.size()-1);return old==0?0:(now-old)/old;}

    double technicalScore(double nl,double ne,double nr,double nm,double bl,double be,double br,double bm){
        double emaScore=(nl>ne?1:-1)+(bl>be?1:-1); double rsiScore=(nr>55?1:nr<45?-1:0)+(br>55?1:br<45?-1:0);
        double momScore=(nm>0.0005?1:nm<-0.0005?-1:0)+(bm>0.0005?1:bm<-0.0005?-1:0);
        return (emaScore*0.4+rsiScore*0.3+momScore*0.3)/2.0;
    }

    void loadNews(TextView out){
        out.setText("Loading Nifty / Bank Nifty news...");
        new Thread(()->{try{
            String u="https://news.google.com/rss/search?q=Nifty+50+OR+Bank+Nifty+when:1d&hl=en-IN&gl=IN&ceid=IN:en";
            HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection(); c.setConnectTimeout(10000); c.setReadTimeout(10000); c.setRequestMethod("GET"); c.setRequestProperty("User-Agent","JellyMarket/3.0");
            String xml=read(c.getInputStream()); org.w3c.dom.Document doc=javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new ByteArrayInputStream(xml.getBytes("UTF-8")));
            org.w3c.dom.NodeList items=doc.getElementsByTagName("item"); StringBuilder b=new StringBuilder(); int count=Math.min(5,items.getLength()),pos=0,neg=0;
            for(int i=0;i<count;i++){org.w3c.dom.Element item=(org.w3c.dom.Element)items.item(i);String title=item.getElementsByTagName("title").item(0).getTextContent().trim();String low=title.toLowerCase(Locale.US);
                if(low.matches(".*(surge|gain|rally|rise|bull|record|positive|buy|growth|up).*"))pos++;
                if(low.matches(".*(fall|drop|crash|bear|loss|negative|sell|weak|down|slump).*"))neg++;
                b.append("• ").append(title).append("\n\n"); }
            final String sentiment=pos>neg?"POSITIVE":neg>pos?"NEGATIVE":"MIXED";
            final String text=b.length()==0?"No recent headlines found.":"Sentiment: "+sentiment+"\n\n"+b.toString().trim();
            runOnUiThread(()->{out.setText(text);out.setTextColor(sentiment.equals("POSITIVE")?GREEN:sentiment.equals("NEGATIVE")?RED:YELLOW);});
        }catch(Exception e){runOnUiThread(()->out.setText("News unavailable: "+e.getMessage()));}}).start();
    }

    void setHeaders(HttpURLConnection c,String api,String token){
        c.setRequestProperty("X-PrivateKey",api); c.setRequestProperty("X-ClientLocalIP","0.0.0.0"); c.setRequestProperty("X-ClientPublicIP","0.0.0.0");
        c.setRequestProperty("X-MACAddress","00:00:00:00:00:00"); c.setRequestProperty("Authorization",token.isEmpty()?"":"Bearer "+token);
        c.setRequestProperty("X-UserType","USER"); c.setRequestProperty("X-SourceID","WEB"); c.setRequestProperty("Accept","application/json"); c.setRequestProperty("Content-Type","application/json");
    }
    void write(HttpURLConnection c,String s)throws Exception{OutputStream o=c.getOutputStream();o.write(s.getBytes("UTF-8"));o.close();}
    void update(double ltp,double close,TextView out){double ch=ltp-close,p=close==0?0:ch*100/close;int col=ch>0?GREEN:ch<0?RED:YELLOW;out.setText(String.format(Locale.US,"%,.2f",ltp)+"\n"+String.format(Locale.US,"%+.2f (%+.2f%%)",ch,p));out.setTextColor(col);}
    void speakSummary(){String a="Jelly Market. Nifty aur Bank Nifty ka live technical signal. Current view: "+marketView.getText()+". Signal: "+signal.getText()+". Yeh financial advice nahi hai.";if(tts!=null)tts.speak(a,TextToSpeech.QUEUE_FLUSH,null,"jelly");}
    String read(InputStream is)throws Exception{BufferedReader r=new BufferedReader(new InputStreamReader(is));StringBuilder s=new StringBuilder();String x;while((x=r.readLine())!=null)s.append(x);return s.toString();}
    @Override protected void onPause(){
        super.onPause();
        if(manualLogout || authToken.isEmpty()) return;
        if(timer!=null){ timer.cancel(); timer=null; }
        if(wsHandler!=null && heartbeat!=null) wsHandler.removeCallbacks(heartbeat);
        cancelWatchdog();
        cancelReconnect();
        try{ if(webSocket!=null) webSocket.cancel(); }catch(Exception ignored){}
        runOnUiThread(()->status.setText("Jelly paused • live connection suspended"));
    }

    @Override protected void onResume(){
        super.onResume();
        if(!manualLogout && !authToken.isEmpty() && marketHours()){
            if(timer==null){
                timer=new Timer();
                timer.scheduleAtFixedRate(new TimerTask(){ public void run(){ fetch(); } },15000,15000);
            }
            connectWebSocket();
        }
    }

    @Override protected void onDestroy(){
        manualLogout=true;
        cancelReconnect();
        if(wsHandler!=null && heartbeat!=null) wsHandler.removeCallbacks(heartbeat);
        if(wsHandler!=null) wsHandler.removeCallbacksAndMessages(null);
        cancelWatchdog();
        try{if(webSocket!=null)webSocket.close(1000,"destroy");}catch(Exception ignored){}
        if(timer!=null)timer.cancel();
        if(tts!=null){tts.stop();tts.shutdown();}
        super.onDestroy();
    }

    class PriceChart extends View{
        ArrayList<Float> p=new ArrayList<>();Paint paint=new Paint(1);
        PriceChart(Context c){super(c);}
        void add(double x){p.add((float)x);if(p.size()>80)p.remove(0);invalidate();}
        void clear(){p.clear();invalidate();}
        protected void onDraw(Canvas c){super.onDraw(c);paint.setColor(Color.DKGRAY);paint.setStrokeWidth(1);for(int i=1;i<5;i++)c.drawLine(0,getHeight()*i/5f,getWidth(),getHeight()*i/5f,paint);if(p.size()<2)return;float min=Collections.min(p),max=Collections.max(p),range=Math.max(0.0001f,max-min);paint.setColor(Color.CYAN);paint.setStrokeWidth(4);for(int i=1;i<p.size();i++){float x1=(i-1)*getWidth()/(float)(p.size()-1),x2=i*getWidth()/(float)(p.size()-1);float y1=getHeight()-((p.get(i-1)-min)/range)*(getHeight()-20)-10,y2=getHeight()-((p.get(i)-min)/range)*(getHeight()-20)-10;c.drawLine(x1,y1,x2,y2,paint);}}
    }
}
